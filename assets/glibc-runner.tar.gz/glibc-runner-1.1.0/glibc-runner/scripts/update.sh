#!/system/bin/sh
set -eu

# ====================================================
#  Glibc Runner - Node Runtime Updater
#  Staging -> smoke -> promote -> rollback
#  Usage:
#    update.sh check
#    update.sh node-status
#    update.sh node-apply <vX.Y.Z>
#    update.sh node-apply-bg <vX.Y.Z>
#    update.sh node-rollback-last
#    update.sh openclaw-status
#    update.sh openclaw-apply <ver|latest>
#    update.sh openclaw-apply-bg <ver|latest>
#    update.sh openclaw-rollback-last
#    update.sh backup-info
#    update.sh cleanup
#    update.sh openclaw-status
#    update.sh openclaw-apply <ver|latest>
#    update.sh openclaw-apply-bg <ver|latest>
#    update.sh openclaw-rollback-last
#    update.sh openclaw-status
#    update.sh openclaw-apply <ver|latest>
#    update.sh openclaw-apply-bg <ver|latest>
#    update.sh openclaw-rollback-last
# ====================================================

DIR=${0%/*}
. "$DIR/../settings.ini"

mkdir -p "$run_dir" "$staging_dir" "$backups_dir" "$update_state_dir"

log_msg() { printf '%s\n' "$*"; }
warn_msg() { printf 'WARN: %s\n' "$*" >&2; }
fail_msg() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

normalize_node_ver() {
  IN_VER="$1"
  case "$IN_VER" in
    v*) OUT_VER="$IN_VER" ;;
    *) OUT_VER="v$IN_VER" ;;
  esac
  echo "$OUT_VER" | grep -Eq '^v[0-9]+\.[0-9]+\.[0-9]+$' || fail_msg "invalid node version: $IN_VER (expected vX.Y.Z)"
  printf '%s' "$OUT_VER"
}

acquire_lock() {
  if mkdir "$bootstrap_lock_dir" 2>/dev/null; then
    echo $$ > "$bootstrap_lock_dir/pid"
    trap 'rm -rf "$bootstrap_lock_dir" 2>/dev/null || true' EXIT INT TERM
  else
    _lock_pid="$(cat "$bootstrap_lock_dir/pid" 2>/dev/null || true)"
    if [ -n "$_lock_pid" ] && [ -d "/proc/$_lock_pid" ]; then
      fail_msg "update lock held by PID $_lock_pid"
    fi
    warn_msg "stale lock detected, reclaiming"
    rm -rf "$bootstrap_lock_dir"
    mkdir "$bootstrap_lock_dir" 2>/dev/null || fail_msg "cannot reclaim lock"
    echo $$ > "$bootstrap_lock_dir/pid"
    trap 'rm -rf "$bootstrap_lock_dir" 2>/dev/null || true' EXIT INT TERM
  fi
}

release_lock() {
  rm -rf "$bootstrap_lock_dir" 2>/dev/null || true
}

download_file() {
  _url="$1"
  _out="$2"
  if command -v curl >/dev/null 2>&1; then
    curl -fL --retry 3 --retry-delay 2 "$_url" -o "$_out"
    return $?
  fi
  # Fallback: busybox wget (available on KSU/Magisk)
  busybox wget --no-check-certificate -O "$_out" "$_url"
  return $?
}

restore_node_backup() {
  BACKUP_DIR="$1"
  [ -d "$BACKUP_DIR" ] || fail_msg "backup missing: $BACKUP_DIR"
  [ -f "$BACKUP_DIR/node.real" ] || fail_msg "backup missing: $BACKUP_DIR/node.real"
  [ -d "$BACKUP_DIR/npm" ] || fail_msg "backup missing: $BACKUP_DIR/npm"

  cp -a "$BACKUP_DIR/node.real" "$node_dir/bin/node.real"
  rm -rf "$node_dir/lib/node_modules/npm"
  cp -a "$BACKUP_DIR/npm" "$node_dir/lib/node_modules/npm"
  if [ -d "$BACKUP_DIR/corepack" ] && [ "$(ls -A "$BACKUP_DIR/corepack" 2>/dev/null)" ]; then
    rm -rf "$node_dir/lib/node_modules/corepack"
    cp -a "$BACKUP_DIR/corepack" "$node_dir/lib/node_modules/corepack"
  fi
}

fix_bin_symlinks() {
  [ -x "$fix_bins_script" ] || { log_msg "fix-bins script missing"; return 1; }
  "$fix_bins_script"
}

cmd_check() {
  [ -x "$node_bin" ] || fail_msg "node wrapper missing: $node_bin"
  [ -x "$npm_bin" ] || fail_msg "npm wrapper missing: $npm_bin"

  log_msg "check:"
  log_msg "- node: $($node_bin -v 2>/dev/null || echo FAIL)"
  log_msg "- npm: $($npm_bin --version 2>/dev/null || echo FAIL)"
  log_msg "- glibc_ldso: $([ -f "$glibc_ldso" ] && echo OK || echo MISSING)"
  log_msg "- compat.js: $([ -f "$compat_js" ] && echo OK || echo MISSING)"
}

cmd_node_status() {
  log_msg "node-status:"
  log_msg "- current_node: $($node_bin -v 2>/dev/null || echo unknown)"
  log_msg "- current_npm: $($npm_bin --version 2>/dev/null || echo unknown)"
  if [ -f "$node_last_file" ]; then
    log_msg "- last_node_update:"
    sed 's/^/  /' "$node_last_file"
  else
    log_msg "- last_node_update: none"
  fi
}

cmd_node_apply() {
  [ $# -ge 1 ] || fail_msg "missing node version (example: v24.14.1)"

  TARGET_VER="$(normalize_node_ver "$1")"
  TARGET_ARCH="linux-arm64"
  PKG="node-${TARGET_VER}-${TARGET_ARCH}.tar.gz"
  URL="https://nodejs.org/dist/${TARGET_VER}/${PKG}"

  # Allow custom base URL override
  if [ -f "$bootstrap_node_url_file" ]; then
    CUSTOM_BASE="$(cat "$bootstrap_node_url_file" 2>/dev/null || true)"
    if [ -n "$CUSTOM_BASE" ]; then
      URL="${CUSTOM_BASE}/${TARGET_VER}/${PKG}"
    fi
  fi

  acquire_lock

  # Clean stale staging dirs from previous interrupted runs
  for _stale in "$staging_dir"/node-runtime-*; do
    [ -d "$_stale" ] && rm -rf "$_stale"
  done
  unset _stale

  TS="$(date +%Y%m%d-%H%M%S)"
  STAGE="$staging_dir/node-runtime-$TS"
  STAGE_DIR="$STAGE/node"
  BACKUP_DIR="$backups_dir/node-runtime-$TS"

  mkdir -p "$STAGE_DIR" "$BACKUP_DIR"

  [ -f "$node_real" ] || fail_msg "missing live node binary: $node_real"
  [ -d "$node_dir/lib/node_modules/npm" ] || fail_msg "missing live npm dir"

  log_msg "updating node runtime to $TARGET_VER"
  download_file "$URL" "$STAGE/$PKG" || fail_msg "download failed: $URL"

  # Extract
  tar -xzf "$STAGE/$PKG" --strip-components=1 -C "$STAGE_DIR" || fail_msg "extraction failed: $PKG"
  [ -f "$STAGE_DIR/bin/node" ] || fail_msg "stage node binary missing"
  [ -d "$STAGE_DIR/lib/node_modules/npm" ] || fail_msg "stage npm missing"

  # Backup current
  cp -a "$node_real" "$BACKUP_DIR/node.real"
  cp -a "$node_dir/lib/node_modules/npm" "$BACKUP_DIR/npm"
  if [ -d "$node_dir/lib/node_modules/corepack" ]; then
    cp -a "$node_dir/lib/node_modules/corepack" "$BACKUP_DIR/corepack"
  else
    mkdir -p "$BACKUP_DIR/corepack"
  fi

  # Validate stage binary via glibc loader
  if ! "$glibc_ldso" --library-path "$glibc_dir" "$STAGE_DIR/bin/node" -v >/dev/null 2>&1; then
    fail_msg "stage node binary failed glibc-loader validation"
  fi

  # Promote
  cp -a "$STAGE_DIR/bin/node" "$node_dir/bin/node.real"
  rm -rf "$node_dir/lib/node_modules/npm"
  cp -a "$STAGE_DIR/lib/node_modules/npm" "$node_dir/lib/node_modules/npm"
  if [ -d "$STAGE_DIR/lib/node_modules/corepack" ]; then
    rm -rf "$node_dir/lib/node_modules/corepack"
    cp -a "$STAGE_DIR/lib/node_modules/corepack" "$node_dir/lib/node_modules/corepack"
  fi

  # Live verify
  if ! "$node_bin" -v >/dev/null 2>&1; then
    warn_msg "node verify failed, restoring backup"
    restore_node_backup "$BACKUP_DIR"
    log_msg "NODE_UPDATE_ROLLBACK=1"
    fail_msg "rollback complete: node runtime verification failed"
  fi

  if ! "$npm_bin" --version >/dev/null 2>&1; then
    warn_msg "npm verify failed, restoring backup"
    restore_node_backup "$BACKUP_DIR"
    log_msg "NODE_UPDATE_ROLLBACK=1"
    fail_msg "rollback complete: npm verification failed"
  fi

  # Save update state
  mkdir -p "$update_state_dir"
  {
    echo "TS=$TS"
    echo "BACKUP_DIR=$BACKUP_DIR"
    echo "TARGET_VER=$TARGET_VER"
  } > "$node_last_file"

  # Sync bootstrap-state.env so WebUI/status reflects new version
  _new_node_ver="$($node_bin -v 2>/dev/null || echo unknown)"
  _new_npm_ver="$($npm_bin --version 2>/dev/null || echo unknown)"
  cat > "$bootstrap_state_file" <<BSTATE
STATE=NODE_READY
NODE_READY=1
LAST_ACTION=update:node-apply:success
LAST_TS=$(date +%s)
NODE_VERSION=$_new_node_ver
NPM_VERSION=$_new_npm_ver
BSTATE
  unset _new_node_ver _new_npm_ver

  chown root:root "$node_real" 2>/dev/null || true

  rm -rf "$STAGE" 2>/dev/null || true
  log_msg "node apply done"
  log_msg "NODE_UPDATE_SUCCESS=1"
  log_msg "node_version=$($node_bin -v 2>/dev/null || echo unknown)"
  log_msg "npm_version=$($npm_bin --version 2>/dev/null || echo unknown)"
  log_msg "backup=$BACKUP_DIR"
}

cmd_node_apply_bg() {
  [ $# -ge 1 ] || fail_msg "missing node version (example: v24.14.1)"
  TARGET_VER="$(normalize_node_ver "$1")"
  LOG="$update_state_dir/node-apply-bg-${TARGET_VER#v}-$(date +%Y%m%d-%H%M%S).log"
  nohup "$0" node-apply "$TARGET_VER" > "$LOG" 2>&1 &
  log_msg "node-apply-bg started"
  log_msg "log=$LOG"
}

cmd_node_rollback_last() {
  [ -f "$node_last_file" ] || fail_msg "no last node update state"
  # Validate file contains only safe key=value lines before sourcing (skip empty lines)
  if grep -qvE '^(TS|BACKUP_DIR|TARGET_VER)=[A-Za-z0-9_./@: -]*$|^$' "$node_last_file" 2>/dev/null; then
    fail_msg "node last state file contains unexpected content"
  fi
  . "$node_last_file"
  [ -n "${BACKUP_DIR:-}" ] || fail_msg "invalid node last state (missing BACKUP_DIR)"

  restore_node_backup "$BACKUP_DIR"

  "$node_bin" -v >/dev/null 2>&1 || fail_msg "rollback restore done but node verify failed"
  "$npm_bin" --version >/dev/null 2>&1 || fail_msg "rollback restore done but npm verify failed"

  log_msg "node-rollback-last done"
  log_msg "node_version=$($node_bin -v 2>/dev/null || echo unknown)"
  log_msg "npm_version=$($npm_bin --version 2>/dev/null || echo unknown)"
}

# ── Openclaw commands ─────────────────────────────────
cmd_openclaw_status() {
  log_msg "openclaw-status:"
  if [ -x "$openclaw_bin" ]; then
    log_msg "- version: $($openclaw_bin --version 2>/dev/null | head -1 || echo unknown)"
  else
    log_msg "- version: not installed"
  fi
  _gw_pid=$(pgrep -f "openclaw-gateway" 2>/dev/null | head -1)
  if [ -n "$_gw_pid" ] && [ -d "/proc/$_gw_pid" ]; then
    log_msg "- gateway: running (PID: $_gw_pid)"
  else
    log_msg "- gateway: stopped"
  fi
}

cmd_openclaw_apply() {
  [ $# -ge 1 ] || fail_msg "missing openclaw version (example: latest or 2026.4.9)"

  SPEC="$1"
  if [ "$SPEC" = "latest" ]; then
    PKG_SPEC="openclaw"
  else
    PKG_SPEC="openclaw@${SPEC}"
  fi

  acquire_lock

  # Check if gateway was running before update
  _was_running=false
  _gw_pid=$(pgrep -f "openclaw-gateway" 2>/dev/null | head -1)
  if [ -n "$_gw_pid" ] && [ -d "/proc/$_gw_pid" ]; then
    _was_running=true
    log_msg "stopping gateway before update..."
    "$service_script" stop 2>/dev/null || true
    sleep 1
  fi

  log_msg "installing $PKG_SPEC..."
  "$npm_bin" install -g "$PKG_SPEC" 2>&1 || fail_msg "npm install -g $PKG_SPEC failed"

  # Fix bin wrappers after npm install
  if [ -x "$fix_bins_script" ]; then
    "$fix_bins_script" 2>&1 || warn_msg "fix-bins had errors"
  fi

  log_msg "openclaw-apply done"
  if [ -x "$openclaw_bin" ]; then
    log_msg "openclaw_version=$($openclaw_bin --version 2>/dev/null | head -1 || echo unknown)"
  fi

  # Restart gateway if it was running before update
  if [ "$_was_running" = true ]; then
    log_msg "restarting gateway..."
    "$service_script" start 2>/dev/null || warn_msg "gateway restart failed"
  fi
}

cmd_openclaw_apply_bg() {
  [ $# -ge 1 ] || fail_msg "missing openclaw version (example: latest or 2026.4.9)"
  SPEC="$1"
  LOG="$update_state_dir/openclaw-apply-bg-${SPEC}-$(date +%Y%m%d-%H%M%S).log"
  SIGNAL="${run_dir}/notify-openclaw.signal"
  # Run in background with signal file notification on completion
  nohup sh -c "
    \"$0\" openclaw-apply \"$SPEC\" > \"$LOG\" 2>&1
    _rc=\$?
    if [ \$_rc -eq 0 ]; then
      _ver=\$(\"$openclaw_bin\" --version 2>/dev/null | head -1 || echo unknown)
      echo \"ok|Openclaw installed: \$_ver\" > \"$SIGNAL\"
    else
      echo \"err|Openclaw install failed (exit \$_rc) — check log\" > \"$SIGNAL\"
    fi
  " > /dev/null 2>&1 &
  log_msg "openclaw-apply-bg started"
  log_msg "log=$LOG"
}

cmd_openclaw_rollback_last() {
  log_msg "openclaw packages don't support binary rollback."
  log_msg "To rollback, install a specific version:"
  log_msg "  update.sh openclaw-apply <version>"
  log_msg "  e.g.: update.sh openclaw-apply 2026.4.1"
}

# ── Maintenance commands ──────────────────────────────
cmd_backup_info() {
  # Node backup info
  _has_backup=0
  _backup_ver=""
  _backup_size="0K"
  if [ -f "$node_last_file" ]; then
    . "$node_last_file"
    if [ -n "${BACKUP_DIR:-}" ] && [ -d "$BACKUP_DIR" ]; then
      _has_backup=1
      _backup_ver="${TARGET_VER:-unknown}"
      _backup_size=$(du -sh "$BACKUP_DIR" 2>/dev/null | cut -f1)
    fi
  fi

  # Background logs
  _logs_count=0
  _logs_size="0K"
  if [ -d "$update_state_dir" ]; then
    _logs_count=$(find "$update_state_dir" -name '*.log' 2>/dev/null | wc -l)
    if [ "$_logs_count" -gt 0 ]; then
      _logs_size=$(du -shc "$update_state_dir"/*.log 2>/dev/null | tail -1 | cut -f1)
    fi
  fi

  # Staging leftovers
  _staging_size="0K"
  if [ -d "$staging_dir" ] && [ "$(ls -A "$staging_dir" 2>/dev/null)" ]; then
    _staging_size=$(du -sh "$staging_dir" 2>/dev/null | cut -f1)
  fi

  # Total
  _total_size="0K"
  _dirs_to_sum=""
  [ -d "$backups_dir" ] && _dirs_to_sum="$backups_dir"
  [ -d "$staging_dir" ] && _dirs_to_sum="$_dirs_to_sum $staging_dir"
  [ -d "$update_state_dir" ] && _dirs_to_sum="$_dirs_to_sum $update_state_dir"
  if [ -n "$_dirs_to_sum" ]; then
    _total_size=$(du -shc $_dirs_to_sum 2>/dev/null | tail -1 | cut -f1)
  fi

  echo "has_node_backup=$_has_backup"
  echo "node_backup_ver=$_backup_ver"
  echo "node_backup_size=$_backup_size"
  echo "bg_logs_count=$_logs_count"
  echo "bg_logs_size=$_logs_size"
  echo "staging_size=$_staging_size"
  echo "total_size=$_total_size"
}

cmd_cleanup() {
  # Calculate size before cleanup
  _dirs_to_sum=""
  [ -d "$backups_dir" ] && _dirs_to_sum="$backups_dir"
  [ -d "$staging_dir" ] && _dirs_to_sum="$_dirs_to_sum $staging_dir"
  [ -d "$update_state_dir" ] && _dirs_to_sum="$_dirs_to_sum $update_state_dir"
  _freed="0K"
  if [ -n "$_dirs_to_sum" ]; then
    _freed=$(du -shc $_dirs_to_sum 2>/dev/null | tail -1 | cut -f1)
  fi

  # Remove backups
  if [ -d "$backups_dir" ]; then
    rm -rf "$backups_dir"/*
    log_msg "cleaned backups"
  fi

  # Remove staging leftovers
  if [ -d "$staging_dir" ]; then
    rm -rf "$staging_dir"/*
    log_msg "cleaned staging"
  fi

  # Remove background logs
  if [ -d "$update_state_dir" ]; then
    rm -f "$update_state_dir"/*.log
    log_msg "cleaned bg-logs"
  fi

  # Remove node-last state (no backup to restore anymore)
  rm -f "$node_last_file"

  log_msg "cleanup done"
  echo "cleanup_freed=$_freed"
}

cmd_openclaw_info() {
  # Openclaw version
  _oc_ver=""
  if [ -x "$openclaw_bin" ]; then
    _oc_ver=$($openclaw_bin --version 2>/dev/null | head -1 || echo "")
  fi

  # npm cache size
  _npm_cache_dir="${home_dir}/.npm/_cacache"
  _npm_cache_size="0K"
  if [ -d "$_npm_cache_dir" ]; then
    _npm_cache_size=$(du -sh "$_npm_cache_dir" 2>/dev/null | cut -f1)
  fi

  # Openclaw package size
  _oc_pkg_dir="${node_dir}/lib/node_modules/openclaw"
  _oc_pkg_size="0K"
  if [ -d "$_oc_pkg_dir" ]; then
    _oc_pkg_size=$(du -sh "$_oc_pkg_dir" 2>/dev/null | cut -f1)
  fi

  # Openclaw bg-logs
  _oc_logs_count=0
  _oc_logs_size="0K"
  if [ -d "$update_state_dir" ]; then
    _oc_logs_count=$(find "$update_state_dir" -name 'openclaw-apply-bg-*.log' 2>/dev/null | wc -l)
    if [ "$_oc_logs_count" -gt 0 ]; then
      _oc_logs_size=$(du -shc "$update_state_dir"/openclaw-apply-bg-*.log 2>/dev/null | tail -1 | cut -f1)
    fi
  fi

  # Gateway log size
  _gw_log_size="0K"
  if [ -f "$openclaw_log" ]; then
    _gw_log_size=$(du -sh "$openclaw_log" 2>/dev/null | cut -f1)
  fi
  _svc_log_size="0K"
  if [ -f "$openclaw_service_log" ]; then
    _svc_log_size=$(du -sh "$openclaw_service_log" 2>/dev/null | cut -f1)
  fi

  echo "oc_version=$_oc_ver"
  echo "oc_pkg_size=$_oc_pkg_size"
  echo "npm_cache_size=$_npm_cache_size"
  echo "oc_logs_count=$_oc_logs_count"
  echo "oc_logs_size=$_oc_logs_size"
  echo "gw_log_size=$_gw_log_size"
  echo "svc_log_size=$_svc_log_size"
}

cmd_npm_cache_clean() {
  _npm_cache_dir="${home_dir}/.npm/_cacache"
  _freed="0K"
  _total="0K"

  # Calculate sizes before cleaning
  _dirs=""
  [ -d "$_npm_cache_dir" ] && _dirs="$_npm_cache_dir"
  [ -f "$openclaw_log" ] && _dirs="$_dirs $openclaw_log"
  [ -f "$openclaw_service_log" ] && _dirs="$_dirs $openclaw_service_log"

  # bg-logs for openclaw
  _oc_bg_logs=""
  if [ -d "$update_state_dir" ]; then
    _oc_bg_logs=$(find "$update_state_dir" -name 'openclaw-apply-bg-*.log' 2>/dev/null || true)
  fi

  if [ -n "$_dirs" ] || [ -n "$_oc_bg_logs" ]; then
    _all="$_dirs $_oc_bg_logs"
    _total=$(du -shc $_all 2>/dev/null | tail -1 | cut -f1)
  fi

  # Clean npm cache
  if [ -d "$_npm_cache_dir" ]; then
    rm -rf "$_npm_cache_dir"
    log_msg "cleaned npm cache"
  fi

  # Clean gateway logs
  if [ -f "$openclaw_log" ]; then
    : > "$openclaw_log"
    log_msg "cleaned gateway log"
  fi
  if [ -f "$openclaw_service_log" ]; then
    : > "$openclaw_service_log"
    log_msg "cleaned service log"
  fi

  # Clean openclaw bg-logs
  if [ -n "$_oc_bg_logs" ]; then
    echo "$_oc_bg_logs" | xargs rm -f 2>/dev/null
    log_msg "cleaned openclaw bg-logs"
  fi

  log_msg "npm-cache-clean done"
  echo "cleanup_freed=$_total"
}

case "${1:-}" in
  check) cmd_check ;;
  node-status) cmd_node_status ;;
  node-apply) shift; cmd_node_apply "$@" ;;
  node-apply-bg) shift; cmd_node_apply_bg "$@" ;;
  node-rollback-last) cmd_node_rollback_last ;;
  openclaw-status) cmd_openclaw_status ;;
  openclaw-apply) shift; cmd_openclaw_apply "$@" ;;
  openclaw-apply-bg) shift; cmd_openclaw_apply_bg "$@" ;;
  openclaw-rollback-last) cmd_openclaw_rollback_last ;;
  openclaw-info) cmd_openclaw_info ;;
  npm-cache-clean) cmd_npm_cache_clean ;;
  backup-info) cmd_backup_info ;;
  cleanup) cmd_cleanup ;;
  *)
    echo "Usage: $0 {check|node-status|node-apply|node-rollback-last|openclaw-apply|openclaw-info|npm-cache-clean|backup-info|cleanup}" >&2
    exit 2
    ;;
esac
