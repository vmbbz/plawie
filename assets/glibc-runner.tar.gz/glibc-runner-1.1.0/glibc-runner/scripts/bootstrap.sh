#!/system/bin/sh
set -eu

# ====================================================
#  Glibc Runner Module - Bootstrap State Machine
#  States: BOOTSTRAP_READY -> NODE_INSTALLING -> NODE_READY
#                                  |-> NODE_FAILED
#  Usage: bootstrap.sh {status|set-node-url <url>|install-node [version]|reset-state}
# ====================================================

DIR=${0%/*}
. "$DIR/../settings.ini"

mkdir -p "$run_dir" "$tmp_dir" "$staging_dir" "$backups_dir" "$config_dir" "$home_dir"

# ── State management ─────────────────────────────────

state_default() {
  cat <<EOF
STATE=BOOTSTRAP_READY
NODE_READY=0
LAST_ACTION=none
LAST_TS=$(date +%s)
NODE_VERSION=none
NPM_VERSION=none
EOF
}

state_load() {
  if [ -f "$bootstrap_state_file" ]; then
    . "$bootstrap_state_file"
  else
    eval "$(state_default)"
  fi
  : "${STATE:=BOOTSTRAP_READY}"
  : "${NODE_READY:=0}"
  : "${LAST_ACTION:=none}"
  : "${LAST_TS:=0}"
  : "${NODE_VERSION:=none}"
  : "${NPM_VERSION:=none}"
}

state_save() {
  cat > "$bootstrap_state_file" <<EOF
STATE=$STATE
NODE_READY=$NODE_READY
LAST_ACTION=$LAST_ACTION
LAST_TS=$LAST_TS
NODE_VERSION=$NODE_VERSION
NPM_VERSION=$NPM_VERSION
EOF
}

state_set() {
  STATE="$1"
  LAST_ACTION="$2"
  LAST_TS="$(date +%s)"
  state_save
}

log_bootstrap() {
  _log_ts="$(date '+%Y-%m-%d %H:%M:%S')"
  printf '%s %s\n' "$_log_ts" "$*" | tee -a "$bootstrap_log"
}

# ── Locking ───────────────────────────────────────────

ensure_lock() {
  if mkdir "$bootstrap_lock_dir" 2>/dev/null; then
    echo $$ > "$bootstrap_lock_dir/pid"
    trap 'rm -rf "$bootstrap_lock_dir" 2>/dev/null || true' EXIT INT TERM
  else
    _lock_pid="$(cat "$bootstrap_lock_dir/pid" 2>/dev/null || true)"
    if [ -n "$_lock_pid" ] && [ -d "/proc/$_lock_pid" ]; then
      echo "LOCKED: bootstrap operation already running (PID $_lock_pid)"
      exit 1
    fi
    rm -rf "$bootstrap_lock_dir"
    mkdir "$bootstrap_lock_dir" 2>/dev/null || { echo "cannot acquire lock"; exit 1; }
    echo $$ > "$bootstrap_lock_dir/pid"
    trap 'rm -rf "$bootstrap_lock_dir" 2>/dev/null || true' EXIT INT TERM
  fi
}

# ── Helpers ───────────────────────────────────────────

load_env() {
  if [ -f "$bootstrap_env" ]; then
    . "$bootstrap_env"
  fi
  : "${NODE_BASE_URL:=https://nodejs.org/dist}"
  # Store config default separately to avoid collision with state's NODE_VERSION
  DEFAULT_NODE_VERSION="${NODE_VERSION:-24.14.1}"
  : "${NODE_BUNDLE_SHA256:=}"
}

download_file() {
  URL="$1"
  OUT="$2"
  if command -v curl >/dev/null 2>&1; then
    curl -fL --retry 3 --retry-delay 2 "$URL" -o "$OUT"
    return $?
  fi
  # Fallback: busybox wget (available on KSU/Magisk)
  busybox wget --no-check-certificate -O "$OUT" "$URL"
  return $?
}

sha256_file() {
  sha256sum "$1" | awk '{print $1}'
}

normalize_version() {
  IN_VER="$1"
  case "$IN_VER" in
    v*) OUT_VER="$IN_VER" ;;
    *) OUT_VER="v$IN_VER" ;;
  esac
  echo "$OUT_VER" | grep -Eq '^v[0-9]+\.[0-9]+\.[0-9]+$' || {
    echo "invalid version: $IN_VER (expected vX.Y.Z)"
    exit 1
  }
  printf '%s' "$OUT_VER"
}

# ── Node wrapper/compat generation ───────────────────

generate_compat_js() {
  TARGET_DIR="$1"
  mkdir -p "$TARGET_DIR/lib"
  cat > "$TARGET_DIR/lib/compat.js" << 'COMPAT'
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');

// Fix 1: process.execPath -> wrapper script (not node.real)
const WRAPPER = path.join('/data/adb/glibc-runner/node/bin/node');
try {
  if (fs.existsSync(WRAPPER)) {
    Object.defineProperty(process, 'execPath', {
      value: WRAPPER, writable: true, configurable: true
    });
  }
} catch (_) {}

// Fix 2: os.networkInterfaces() -> EACCES on Android
const _origNet = os.networkInterfaces;
os.networkInterfaces = function networkInterfaces() {
  try {
    return _origNet.call(os);
  } catch (_) {
    return {
      lo: [{
        address: '127.0.0.1',
        netmask: '255.0.0.0',
        family: 'IPv4',
        mac: '00:00:00:00:00:00',
        internal: true,
        cidr: '127.0.0.1/8',
      }]
    };
  }
};

// Fix 3: os.cpus() -> [] on Android (SELinux blocks /proc/stat)
const _origCpus = os.cpus;
os.cpus = function cpus() {
  const r = _origCpus.call(os);
  if (r.length > 0) return r;
  return [
    { model: 'ARM Cortex', speed: 1800,
      times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 } },
    { model: 'ARM Cortex', speed: 1800,
      times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 } },
  ];
};

// Fix 4: HOME propagation guard — also override root default "/"
if (!process.env.HOME || process.env.HOME === '/') {
  process.env.HOME = '/data/adb/glibc-runner/home';
}
COMPAT
}

generate_node_wrapper() {
  TARGET_DIR="$1"
  cat > "$TARGET_DIR/bin/node" << 'WRAPPER'
#!/system/bin/sh
unset LD_PRELOAD
LDSO="/data/adb/glibc-runner/lib/glibc/ld-linux-aarch64.so.1"
GLIBC="/data/adb/glibc-runner/lib/glibc"
REAL="$(dirname "$0")/node.real"
COMPAT="/data/adb/glibc-runner/node/lib/compat.js"

# Override HOME if unset or root default "/"
case "$HOME" in
  ""|/) export HOME="/data/adb/glibc-runner/home" ;;
esac
export TMPDIR="${TMPDIR:-/data/adb/glibc-runner/tmp}"

# Inject compat.js via NODE_OPTIONS (idempotent)
if [ -f "$COMPAT" ]; then
    case "${NODE_OPTIONS:-}" in
        *"$COMPAT"*) ;;
        *) export NODE_OPTIONS="${NODE_OPTIONS:+$NODE_OPTIONS }--require $COMPAT" ;;
    esac
fi

# Hoist leading --flags into NODE_OPTIONS (ld.so doesn't understand node flags)
_COUNT=0
for _a in "$@"; do
    case "$_a" in --*) _COUNT=$((_COUNT+1)) ;; *) break ;; esac
done
if [ "$_COUNT" -gt 0 ] && [ "$_COUNT" -lt $# ]; then
    while [ $# -gt 0 ]; do
        case "$1" in
            --*) NODE_OPTIONS="${NODE_OPTIONS:+$NODE_OPTIONS }$1"; shift ;;
            *) break ;;
        esac
    done
    export NODE_OPTIONS
fi

exec "$LDSO" --library-path "$GLIBC" "$REAL" "$@"
WRAPPER
  chmod 755 "$TARGET_DIR/bin/node"
}

generate_npm_wrapper() {
  TARGET_DIR="$1"
  TOOL_NAME="$2"
  # Remove symlink first to avoid overwriting the JS target file it points to
  rm -f "$TARGET_DIR/bin/$TOOL_NAME"
  cat > "$TARGET_DIR/bin/$TOOL_NAME" << 'EOF'
#!/system/bin/sh
PROD_DIR="/data/adb/glibc-runner/node"
export PATH="$PROD_DIR/bin:$PATH"
export NPM_CONFIG_PREFIX="$PROD_DIR"
export NPM_CONFIG_GLOBALCONFIG="$PROD_DIR/etc/npmrc"
exec "$PROD_DIR/bin/node" "$PROD_DIR/lib/node_modules/npm/bin/TOOL_NAME_PLACEHOLDER-cli.js" "$@"
EOF
  # Replace placeholder with actual tool name
  sed -i "s/TOOL_NAME_PLACEHOLDER/$TOOL_NAME/g" "$TARGET_DIR/bin/$TOOL_NAME"
  chmod 755 "$TARGET_DIR/bin/$TOOL_NAME"
}

generate_npmrc() {
  TARGET_DIR="$1"
  mkdir -p "$TARGET_DIR/etc"
  # Always use production path, not staging path
  echo "prefix=/data/adb/glibc-runner/node" > "$TARGET_DIR/etc/npmrc"
}

# ── install-node ──────────────────────────────────────

install_node() {
  ensure_lock
  load_env
  state_load

  # Clean stale staging dirs from previous interrupted runs
  if [ -d "$staging_dir" ]; then
    for _stale in "$staging_dir"/node-*; do
      [ -d "$_stale" ] && rm -rf "$_stale"
    done
    unset _stale
  fi

  # Accept version from CLI arg, fall back to config
  INSTALL_VERSION="${1:-$DEFAULT_NODE_VERSION}"
  INSTALL_VERSION="$(normalize_version "$INSTALL_VERSION")"

  # Build download URL
  if [ -f "$bootstrap_node_url_file" ]; then
    BASE_URL="$(cat "$bootstrap_node_url_file" 2>/dev/null || true)"
  fi
  : "${BASE_URL:=$NODE_BASE_URL}"
  ARCHIVE_NAME="node-${INSTALL_VERSION}-linux-arm64.tar.gz"
  DOWNLOAD_URL="${BASE_URL}/${INSTALL_VERSION}/${ARCHIVE_NAME}"

  TS="$(date +%Y%m%d-%H%M%S)"
  STAGE="$staging_dir/node-$TS"
  STAGE_NODE="$STAGE/node"
  ARCHIVE_PATH="$STAGE/$ARCHIVE_NAME"
  BACKUP="$backups_dir/node-$TS"

  mkdir -p "$STAGE_NODE" "$BACKUP"

  state_set "NODE_INSTALLING" "install-node:start"
  log_bootstrap "[NODE] download start url=$DOWNLOAD_URL"

  download_file "$DOWNLOAD_URL" "$ARCHIVE_PATH" || {
    log_bootstrap "[NODE] download failed"
    state_set "NODE_FAILED" "install-node:download-fail"
    exit 1
  }

  # Optional SHA256 verification
  if [ -n "$NODE_BUNDLE_SHA256" ]; then
    CALC="$(sha256_file "$ARCHIVE_PATH" || true)"
    [ -n "$CALC" ] || { log_bootstrap "[NODE] sha256 tool missing"; state_set "NODE_FAILED" "install-node:sha256-tool-missing"; exit 1; }
    [ "$CALC" = "$NODE_BUNDLE_SHA256" ] || {
      log_bootstrap "[NODE] sha256 mismatch expected=$NODE_BUNDLE_SHA256 got=$CALC"
      state_set "NODE_FAILED" "install-node:sha256-mismatch"
      exit 1
    }
    log_bootstrap "[NODE] sha256 verify ok"
  else
    log_bootstrap "[NODE] sha256 skipped (not configured)"
  fi

  # Extract
  log_bootstrap "[NODE] extracting archive..."
  tar -xzf "$ARCHIVE_PATH" -C "$STAGE_NODE" --strip-components=1 || {
    log_bootstrap "[NODE] extraction failed"
    state_set "NODE_FAILED" "install-node:extract-fail"
    rm -rf "$STAGE"
    exit 1
  }
  log_bootstrap "[NODE] extracted to staging"

  # Verify extracted tree has bin/node and bin/npm
  [ -f "$STAGE_NODE/bin/node" ] || {
    log_bootstrap "[NODE] staging missing bin/node"
    state_set "NODE_FAILED" "install-node:invalid-tree"
    exit 1
  }
  [ -d "$STAGE_NODE/lib/node_modules/npm" ] || {
    log_bootstrap "[NODE] staging missing lib/node_modules/npm"
    state_set "NODE_FAILED" "install-node:invalid-tree"
    exit 1
  }

  # Rename node binary -> node.real, create wrapper + compat
  mv "$STAGE_NODE/bin/node" "$STAGE_NODE/bin/node.real"
  generate_node_wrapper "$STAGE_NODE"
  generate_compat_js "$STAGE_NODE"
  generate_npmrc "$STAGE_NODE"

  # Generate npm and npx wrappers
  generate_npm_wrapper "$STAGE_NODE" "npm"
  generate_npm_wrapper "$STAGE_NODE" "npx"

  # Smoke test in staging (call node wrapper + npm-cli.js directly, not via npm wrapper)
  SMOKE_VER="$("$STAGE_NODE/bin/node" --version 2>&1)" || {
    log_bootstrap "[NODE] stage smoke failed (node --version)"
    state_set "NODE_FAILED" "install-node:smoke-fail"
    rm -rf "$STAGE"
    exit 1
  }
  log_bootstrap "[NODE] stage smoke ok: $SMOKE_VER"

  SMOKE_NPM="$("$STAGE_NODE/bin/node" "$STAGE_NODE/lib/node_modules/npm/bin/npm-cli.js" --version 2>&1)" || {
    log_bootstrap "[NODE] stage smoke failed (npm --version)"
    state_set "NODE_FAILED" "install-node:smoke-fail"
    rm -rf "$STAGE"
    exit 1
  }
  log_bootstrap "[NODE] npm smoke ok: $SMOKE_NPM"

  # Backup existing node dir if present
  if [ -d "$node_dir" ]; then
    cp -a "$node_dir" "$BACKUP/node"
    log_bootstrap "[NODE] backup created: $BACKUP/node"
  fi

  # Atomic promote: stage -> node.new -> swap
  rm -rf "$node_dir.new"
  cp -a "$STAGE_NODE" "$node_dir.new"

  rm -rf "$node_dir.prev"
  if [ -d "$node_dir" ]; then
    mv "$node_dir" "$node_dir.prev"
  fi
  mv "$node_dir.new" "$node_dir"

  # Live verify
  if ! "$node_bin" --version >/dev/null 2>&1; then
    log_bootstrap "[NODE] live verify failed, rollback"
    rm -rf "$node_dir"
    if [ -d "$node_dir.prev" ]; then
      mv "$node_dir.prev" "$node_dir"
    fi
    state_set "NODE_FAILED" "install-node:rollback"
    exit 1
  fi

  rm -rf "$node_dir.prev" 2>/dev/null || true

  # Update state
  NODE_READY=1
  NODE_VERSION="$($node_bin --version 2>/dev/null || echo unknown)"
  NPM_VERSION="$($npm_bin --version 2>/dev/null || echo unknown)"
  STATE="NODE_READY"
  LAST_ACTION="install-node:success"
  LAST_TS="$(date +%s)"
  state_save

  # Cleanup staging
  rm -rf "$STAGE" 2>/dev/null || true

  log_bootstrap "[NODE] install success node=$NODE_VERSION npm=$NPM_VERSION"
  echo "NODE_INSTALL_OK node=$NODE_VERSION npm=$NPM_VERSION"
}

# ── Commands ──────────────────────────────────────────

status_cmd() {
  load_env
  state_load
  BASE_URL_VIEW="$NODE_BASE_URL"
  if [ -f "$bootstrap_node_url_file" ]; then
    BASE_URL_VIEW="$(cat "$bootstrap_node_url_file" 2>/dev/null || true)"
  fi
  echo "state=$STATE"
  echo "node_ready=$NODE_READY"
  echo "node_version=$NODE_VERSION"
  echo "npm_version=$NPM_VERSION"
  echo "last_action=$LAST_ACTION"
  echo "last_ts=$LAST_TS"
  echo "node_base_url=${BASE_URL_VIEW:-https://nodejs.org/dist}"
  echo "default_node_version=$DEFAULT_NODE_VERSION"
  echo "log=$bootstrap_log"
}

set_node_url_cmd() {
  [ $# -ge 1 ] || { echo "usage: $0 set-node-url <url>"; exit 2; }
  URL="$1"
  mkdir -p "$config_dir"
  printf '%s' "$URL" > "$bootstrap_node_url_file"
  chmod 600 "$bootstrap_node_url_file" 2>/dev/null || true
  echo "node base url set: $URL"
}

reset_state_cmd() {
  STATE="BOOTSTRAP_READY"
  NODE_READY=0
  NODE_VERSION=none
  NPM_VERSION=none
  LAST_ACTION="reset-state"
  LAST_TS="$(date +%s)"
  state_save
  echo "state reset to BOOTSTRAP_READY"
}

case "${1:-}" in
  status) status_cmd ;;
  set-node-url) shift; set_node_url_cmd "$@" ;;
  install-node) shift; install_node "${1:-}" ;;
  reset-state) reset_state_cmd ;;
  *)
    echo "Usage: $0 {status|set-node-url <url>|install-node [version]|reset-state}"
    exit 2
    ;;
esac
