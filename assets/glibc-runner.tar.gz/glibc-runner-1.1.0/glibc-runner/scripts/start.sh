#!/system/bin/sh
# ====================================================
#  Glibc Runner - Boot Entry Point
#  Called by service.d boot script after boot_completed
# ====================================================

DIR=${0%/*}
. "$DIR/../settings.ini"

# Ensure runtime directories exist
mkdir -p "$run_dir" "$tmp_dir" "$home_dir" "$home_dir/.gyp" "$home_dir/.openclaw"
rm -f "$runs_log"

module_version=$(busybox awk -F'=' '!/^ *#/ && /version=/ { print $2 }' "$module_prop" 2>/dev/null)
log Info "Glibc Runner module version: ${module_version}"

# Run bootstrap status check
if [ -x "$bootstrap_script" ]; then
  "$bootstrap_script" status >> "$bootstrap_log" 2>&1 || true
fi

# Start gateway if openclaw is installed and module not disabled
if [ -x "$openclaw_bin" ] && [ ! -f "${module_dir}/disable" ]; then
  "$service_script" start 2>&1 >> "$openclaw_service_log" || true
else
  log Warning "Openclaw not installed or module disabled. Use WebUI to install."
  sed -Ei "s/^description=(\[.*][[:space:]]*)?/description=[ $(date +"%I:%M %P") | Node.js runtime ready ] /g" "$module_prop" 2>/dev/null || true
fi

# Start inotifyd watcher for enable/disable toggle
_inotify_script="${scripts_dir}/glibc-runner.inotify"
if [ -x "$_inotify_script" ]; then
  # Kill any existing glibc-runner inotifyd watchers
  for _pid in $(busybox pidof inotifyd 2>/dev/null); do
    if grep -q "glibc-runner.inotify" "/proc/$_pid/cmdline" 2>/dev/null; then
      kill -9 "$_pid" 2>/dev/null || true
    fi
  done
  echo "$(date +"%I:%M %P") [Info]: Starting glibc-runner inotify watcher" > "$openclaw_service_log"
  inotifyd "$_inotify_script" "$module_dir" >/dev/null 2>&1 &
fi
unset _inotify_script
