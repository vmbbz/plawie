#!/system/bin/sh
# ====================================================
#  Glibc Runner - npm-fix-bins.sh
#  Convert npm symlinks in node/bin to glibc-runner wrappers
#  Run after: npm install -g <package>
#  Safe: only touches symlinks, skips existing wrappers and Node builtins
# ====================================================

DIR=${0%/*}
. "$DIR/../settings.ini"

BIN_DIR="$node_dir/bin"
NODE_BIN="$BIN_DIR/node"
SKIP="node node.real npm npx"
CONVERTED=0
SKIPPED=0

for link in "$BIN_DIR"/*; do
  [ -L "$link" ] || continue
  name=$(basename "$link")

  # Skip Node builtins
  case " $SKIP " in *" $name "*) SKIPPED=$((SKIPPED+1)); continue ;; esac

  target=$(readlink -f "$link" 2>/dev/null)
  [ -f "$target" ] || continue

  rm "$link"
  cat > "$link" <<EOF
#!/system/bin/sh
exec "$NODE_BIN" "$target" "\$@"
EOF
  chmod 755 "$link"
  echo "  ✔ $name → wrapper"
  CONVERTED=$((CONVERTED+1))
done

echo "Done: $CONVERTED converted, $SKIPPED skipped"
