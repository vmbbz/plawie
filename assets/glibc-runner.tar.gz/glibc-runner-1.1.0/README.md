# Glibc Runner for OpenClaw

**Run Node.js and OpenClaw natively on Android — no Termux, no chroot, no container.**

A KernelSU / Magisk / APatch module that ships a minimal glibc runtime, letting you run upstream Linux `node` binaries directly on Android. Includes built-in OpenClaw gateway management with a beautiful WebUI.

---

## Features

- **Native glibc runtime** — 21 prebuilt aarch64 libraries (`ld-linux-aarch64.so.1`, `libc.so.6`, `libssl.so.3`, `libstdc++.so.6`, etc.)
- **Node.js any version** — Install any Node.js version (v18+) directly from nodejs.org, no compilation needed
- **OpenClaw gateway** — One-click install, start/stop toggle, auto-start on boot
- **WebUI dashboard** — KernelSU Manager WebUI with two tabs: Node.js + OpenClaw
- **Boot service** — Automatic gateway start after boot with network stabilization delay
- **Module toggle** — Enable/disable via KernelSU Manager, gateway follows automatically via inotifyd
- **Action button** — Quick toggle gateway from KernelSU Manager's action button
- **Maintenance tools** — Backup/restore Node.js, clean npm cache, manage logs
- **CLI interface** — Full CLI for scripting and automation
- **Upgrade-safe** — Flashing a new module version preserves your node/ directory and data

---

## Requirements

| Requirement | Details |
|---|---|
| **Architecture** | ARM64 (aarch64) only |
| **Root** | KernelSU (≥ 10670), Magisk, or APatch |
| **Android** | 10+ recommended |
| **Storage** | ~50MB for module + ~100MB for Node.js + ~1.2GB for OpenClaw |

---

## Quick Install

### 1. Download & Flash

Download the latest release `.zip` from [Releases](../../releases), then flash it:

- **KernelSU Manager** → Modules → Install from storage → select zip
- **Magisk Manager** → Modules → Install from storage → select zip

### 2. Install Node.js (via WebUI)

Open the module's WebUI in KernelSU Manager:

1. Go to **Modules** → find **Glibc Runner** → tap the **WebUI** icon
2. In the **Node.js** tab, enter version (e.g. `v22.15.0`) and click **Install Node**
3. Wait for installation to complete (~30 seconds)

### 3. Install OpenClaw (optional)

Switch to the **OpenClaw** tab:

1. Enter version or leave `latest`
2. Click **Install / Update**
3. Toggle the **Gateway Power** switch to start

Or via CLI:
```bash
su -c 'glibc-runner.service start'
```

---

## WebUI

The WebUI provides a complete management interface accessible from KernelSU Manager.

### Node.js Tab
- **Runtime Status** — State, Node/npm versions, last action
- **Install Node.js** — Version input + Install button
- **Maintenance** — Backup info, Restore Node, Clean All
- **Bootstrap Log** — Live log with follow/clear

### OpenClaw Tab
- **Gateway Status** — Running state, port, version, installed status
- **Gateway Power** — Toggle switch to start/stop
- **Install / Update** — Version input + Install button
- **Maintenance** — npm cache size, package size, logs, Rollback Version, Clean Cache
- **OpenClaw Log** — Live gateway log with follow/clear

---

## CLI Reference

All commands run as root (`su -c '...'`):

### Service Management

```bash
# Start OpenClaw gateway
su -c 'glibc-runner.service start'

# Stop gateway
su -c 'glibc-runner.service stop'

# Restart gateway
su -c 'glibc-runner.service restart'

# Check gateway status
su -c 'glibc-runner.service gateway-status'

# Check Node.js status
su -c 'glibc-runner.service status'

# Fix bin wrappers after manual npm install
su -c 'glibc-runner.service fix-bins'

# Tail logs
su -c 'glibc-runner.service log openclaw'    # gateway log
su -c 'glibc-runner.service log service'     # service log
su -c 'glibc-runner.service log bootstrap'   # bootstrap log
su -c 'glibc-runner.service log runs'        # runs log
```

### Node.js Management

```bash
# Install/update Node.js
su -c '/data/adb/glibc-runner/scripts/update.sh node-apply v22.15.0'

# Background install (non-blocking)
su -c '/data/adb/glibc-runner/scripts/update.sh node-apply-bg v22.15.0'

# Check Node.js status
su -c '/data/adb/glibc-runner/scripts/update.sh node-status'

# Rollback to previous version
su -c '/data/adb/glibc-runner/scripts/update.sh node-rollback-last'
```

### OpenClaw Management

```bash
# Install/update OpenClaw
su -c '/data/adb/glibc-runner/scripts/update.sh openclaw-apply latest'
su -c '/data/adb/glibc-runner/scripts/update.sh openclaw-apply 2026.4.9'

# Check OpenClaw status
su -c '/data/adb/glibc-runner/scripts/update.sh openclaw-status'

# OpenClaw info (version, cache, sizes)
su -c '/data/adb/glibc-runner/scripts/update.sh openclaw-info'
```

### Maintenance

```bash
# Backup info (Node.js backups, logs, sizes)
su -c '/data/adb/glibc-runner/scripts/update.sh backup-info'

# Clean all backups, staging, logs
su -c '/data/adb/glibc-runner/scripts/update.sh cleanup'

# Clean npm cache and gateway logs
su -c '/data/adb/glibc-runner/scripts/update.sh npm-cache-clean'
```

### Using npm/node directly

```bash
# Run node
su -c '. /data/adb/glibc-runner/settings.ini && node --version'

# Install a global package
su -c '. /data/adb/glibc-runner/settings.ini && npm install -g <package>'

# Run any node script
su -c '. /data/adb/glibc-runner/settings.ini && node /path/to/script.js'
```

---

## Architecture

```
┌─────────────────────────────────────────────────┐
│                  Android Device                  │
│                                                  │
│  ┌────────────────────────────────────────────┐  │
│  │          KernelSU / Magisk / APatch        │  │
│  │                                            │  │
│  │  /data/adb/modules/glibc-runner/           │  │
│  │  ├── module.prop                           │  │
│  │  ├── webroot/        ← WebUI (HTML/JS/CSS) │  │
│  │  ├── action.sh       ← Action button       │  │
│  │  └── system/bin/     ← CLI symlink         │  │
│  │                                            │  │
│  │  /data/adb/glibc-runner/                   │  │
│  │  ├── settings.ini    ← Shared config       │  │
│  │  ├── scripts/                              │  │
│  │  │   ├── glibc-runner.service  ← Service   │  │
│  │  │   ├── bootstrap.sh          ← Installer │  │
│  │  │   ├── update.sh             ← Updater   │  │
│  │  │   ├── start.sh              ← Boot      │  │
│  │  │   ├── glibc-runner.inotify  ← Toggle    │  │
│  │  │   └── npm-fix-bins.sh       ← Fixer     │  │
│  │  ├── lib/glibc/      ← 21 glibc .so files  │  │
│  │  ├── node/                                 │  │
│  │  │   ├── bin/node.real  ← Real ELF binary  │  │
│  │  │   ├── bin/node       ← glibc wrapper    │  │
│  │  │   ├── bin/npm        ← glibc wrapper    │  │
│  │  │   └── bin/openclaw   ← glibc wrapper    │  │
│  │  └── home/            ← $HOME for node     │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Boot Flow:                                      │
│  service.d → wait boot_completed + 25s           │
│           → start.sh                             │
│             → glibc-runner.service start          │
│             → inotifyd (watches disable file)     │
└─────────────────────────────────────────────────┘
```

### How glibc wrappers work

Android uses Bionic libc, but upstream Node.js binaries are linked against GNU glibc. This module solves that by:

1. Shipping prebuilt glibc libraries for aarch64
2. Wrapping every binary with a shell script that invokes the glibc dynamic linker:

```bash
#!/system/bin/sh
GLIBC="/data/adb/glibc-runner/lib/glibc"
LD="$GLIBC/ld-linux-aarch64.so.1"
REAL="/data/adb/glibc-runner/node/bin/node.real"
exec "$LD" --library-path "$GLIBC" "$REAL" "$@"
```

This lets unmodified Linux ELF binaries run on Android without any patching.

---

## Project Structure

```
.
├── META-INF/                    # Magisk/KSU flash metadata
├── module.prop                  # Module metadata
├── customize.sh                 # Flash-time installer
├── service.sh                   # Boot service (→ service.d/)
├── action.sh                    # KSU action button handler
├── uninstall.sh                 # Clean removal
├── glibc.tar.xz                # Prebuilt glibc libs (not in git)
├── glibc-runner/
│   ├── settings.ini             # Shared configuration
│   ├── config/
│   │   └── bootstrap.default.env
│   └── scripts/
│       ├── bootstrap.sh         # Node.js installer
│       ├── glibc-runner.service # Service manager (start/stop/status)
│       ├── update.sh            # Node.js/OpenClaw updater
│       ├── start.sh             # Boot entry point
│       ├── glibc-runner.inotify # Enable/disable toggle handler
│       └── npm-fix-bins.sh      # Fix bin wrappers after npm install
├── system/
│   └── bin/
│       └── glibc-runner.service # CLI symlink (→ PATH)
└── webroot/
    ├── index.html               # WebUI markup
    ├── scripts.js               # WebUI logic
    └── styles.css               # WebUI styling
```

---

## Building from Source

### Prerequisites
- The `glibc.tar.xz` blob containing prebuilt aarch64 glibc libraries (not included in git — see [Releases](../../releases))

### Build the flashable zip

```bash
# Clone the repo
git clone https://github.com/repotitan/glibc-runner-for-openclaw.git
cd glibc-runner-for-openclaw

# Download glibc.tar.xz from releases and place it in the root
# (or build your own — see CONTRIBUTING.md)

# Build zip
zip -r glibc-runner-v1.1.0.zip . \
  -x '.git/*' 'glibc-runner/node/*' 'glibc-runner/lib/glibc/*' \
  'README.md' 'CONTRIBUTING.md' 'LICENSE' '.gitignore'
```

---

## Troubleshooting

### Node.js install fails
```bash
# Check bootstrap log
su -c 'glibc-runner.service log bootstrap'

# Verify network
su -c 'ping -c 1 nodejs.org'

# Manual install with specific URL
su -c '/data/adb/glibc-runner/scripts/bootstrap.sh install-node v22.15.0'
```

### Gateway won't start
```bash
# Check if openclaw is installed
su -c 'ls -la /data/adb/glibc-runner/node/bin/openclaw'

# Check gateway log
su -c 'glibc-runner.service log openclaw'

# Try manual start
su -c 'glibc-runner.service start'
```

### npm can't find git
Git must be available on the device. Install via Termux:
```bash
pkg install git
```
The module automatically adds Termux's bin directory to PATH when running as root.

### High disk usage
```bash
# Check what's using space
su -c '/data/adb/glibc-runner/scripts/update.sh openclaw-info'
su -c '/data/adb/glibc-runner/scripts/update.sh backup-info'

# Clean npm cache (~700MB after openclaw install)
su -c '/data/adb/glibc-runner/scripts/update.sh npm-cache-clean'

# Clean backups and logs
su -c '/data/adb/glibc-runner/scripts/update.sh cleanup'
```

### Module disabled but gateway still running
```bash
# Force stop
su -c 'glibc-runner.service stop'
```

---

## How It Differs from Other Solutions

| Feature | Glibc Runner | Termux proot | Linux Deploy |
|---|---|---|---|
| Root required | Yes (KSU/Magisk) | No | Yes |
| Performance | Native speed | ~10-30% slower | Near native |
| Disk usage | ~10MB + node | ~500MB+ | ~2GB+ |
| Complexity | Flash & go | Manual setup | Complex setup |
| Node.js version | Any (official binaries) | Termux-patched only | Any |
| WebUI management | Yes | No | No |
| Boot auto-start | Yes | No | Manual |

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for development guidelines.

---

## License

[MIT](LICENSE) — use freely, contribute back if you can.

---

<p align="center">
  Made with ❤️ for the Android modding community
</p>
