#!/system/bin/sh
# ====================================================
#  Glibc Runner Module - Installation Script
# ====================================================

SKIPUNZIP=0
SKIPMOUNT=false

if [ "$BOOTMODE" != true ]; then
  ui_print "! Please install in Magisk Manager or KernelSU Manager"
  ui_print "! Install from recovery is NOT supported"
  abort "-----------------------------------------------------------"
elif [ "$KSU" = true ] && [ "$KSU_VER_CODE" -lt 10670 ]; then
  abort "error: Please update your KernelSU and KernelSU Manager"
fi

# ── Validate ARM64 architecture ──
DEVICE_ARCH="$(uname -m 2>/dev/null || getprop ro.product.cpu.abi 2>/dev/null || echo unknown)"
case "$DEVICE_ARCH" in
  aarch64|arm64*) ;;
  *)
    ui_print "! Unsupported architecture: $DEVICE_ARCH"
    ui_print "! This module requires ARM64 (aarch64)"
    abort "-----------------------------------------------------------"
    ;;
esac

CUSTOM_DIR="/data/adb/glibc-runner"
CONFIG_DIR="$CUSTOM_DIR/config"
SCRIPTS_DIR="$CUSTOM_DIR/scripts"
RUN_DIR="$CUSTOM_DIR/run"
TMP_DIR="$CUSTOM_DIR/tmp"
HOME_DIR="$CUSTOM_DIR/home"
STAGING_DIR="$CUSTOM_DIR/staging"
BACKUPS_DIR="$CUSTOM_DIR/backups"
GLIBC_DIR="$CUSTOM_DIR/lib/glibc"

# ── Upgrade detection ──
IS_UPGRADE=false
if [ -d "$CUSTOM_DIR/node" ]; then
  IS_UPGRADE=true
  ui_print "============================================="
  ui_print "       UPGRADE MODE"
  ui_print "============================================="
  ui_print "- Preserving existing node/ directory"
  ui_print ""
else
  ui_print "============================================="
  ui_print "       FRESH INSTALL"
  ui_print "============================================="
  ui_print ""
fi

# ── Stop existing service ──
if [ -f "$CUSTOM_DIR/scripts/glibc-runner.service" ]; then
  ui_print "- Stopping existing glibc-runner service"
  "$CUSTOM_DIR/scripts/glibc-runner.service" stop >/dev/null 2>&1 || true
  sleep 1
fi

# ── Create directories ──
ui_print "- Creating runtime directories"
mkdir -p "$CUSTOM_DIR" "$CONFIG_DIR" "$SCRIPTS_DIR" "$RUN_DIR" "$TMP_DIR" "$HOME_DIR" "$STAGING_DIR" "$BACKUPS_DIR" "$GLIBC_DIR"

# ── Ensure busybox is available (KSU/APatch/Magisk) ──
if ! command -v busybox >/dev/null 2>&1; then
  export PATH="/data/adb/ksu/bin:/data/adb/ap/bin:/data/adb/magisk:$PATH"
fi

# ── Extract glibc libs (skip on upgrade if already present) ──
if [ "$IS_UPGRADE" = true ] && [ -f "$GLIBC_DIR/ld-linux-aarch64.so.1" ]; then
  ui_print "- Glibc libraries already present (skipping extraction)"
  rm -f "$MODPATH/glibc.tar.xz"
else
  ui_print "- Extracting glibc runtime libraries"
  if tar -xf "$MODPATH/glibc.tar.xz" -C "$GLIBC_DIR" 2>/dev/null; then
    : # ok — tar has native xz support
  elif command -v xz >/dev/null 2>&1; then
    xz -dc "$MODPATH/glibc.tar.xz" | tar -xf - -C "$GLIBC_DIR" || abort "Failed to extract glibc.tar.xz"
  elif command -v busybox >/dev/null 2>&1 && busybox xz -h >/dev/null 2>&1; then
    busybox xz -dc "$MODPATH/glibc.tar.xz" | busybox tar -xf - -C "$GLIBC_DIR" || abort "Failed to extract glibc.tar.xz"
  else
    abort "Cannot extract glibc.tar.xz: neither tar with xz support nor xz/busybox found"
  fi
  rm -f "$MODPATH/glibc.tar.xz"
fi

# ── Fix libc.so if linker script ──
if [ -f "$GLIBC_DIR/libc.so" ]; then
  MAGIC=$(dd if="$GLIBC_DIR/libc.so" bs=4 count=1 2>/dev/null \
          | od -A n -t x1 | tr -d ' \n')
  if [ "$MAGIC" != "7f454c46" ]; then
    rm "$GLIBC_DIR/libc.so"
    ln -s "$GLIBC_DIR/libc.so.6" "$GLIBC_DIR/libc.so"
    ui_print "- Fixed libc.so (linker script → symlink)"
  fi
fi

# ── Install scripts and config ──
ui_print "- Installing scripts and config"
rm -rf "$SCRIPTS_DIR"
mv -f "$MODPATH/glibc-runner/scripts" "$SCRIPTS_DIR"
mv -f "$MODPATH/glibc-runner/settings.ini" "$CUSTOM_DIR/settings.ini"

if [ ! -f "$CONFIG_DIR/bootstrap.env" ] && [ -f "$MODPATH/glibc-runner/config/bootstrap.default.env" ]; then
  cp -f "$MODPATH/glibc-runner/config/bootstrap.default.env" "$CONFIG_DIR/bootstrap.env"
fi

rm -rf "$MODPATH/glibc-runner"

# ── Bootstrap state ──
ui_print "- Initializing bootstrap state"
if [ "$IS_UPGRADE" = true ] && [ -f "$RUN_DIR/bootstrap-state.env" ]; then
  ui_print "  (preserving existing bootstrap state)"
else
  cat > "$RUN_DIR/bootstrap-state.env" <<EOF
STATE=BOOTSTRAP_READY
NODE_READY=0
LAST_ACTION=flash-install
LAST_TS=$(date +%s)
NODE_VERSION=none
NPM_VERSION=none
EOF
fi

# ── Permissions ──
ui_print "- Setting permissions"
set_perm_recursive "$CUSTOM_DIR" 0 0 0755 0755
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
chmod 600 "$CONFIG_DIR/bootstrap.env" 2>/dev/null || true
chmod 755 "$SCRIPTS_DIR"/*.sh "$SCRIPTS_DIR"/*.service "$SCRIPTS_DIR"/*.inotify 2>/dev/null || true

# ── Install boot service ──
SERVICE_DIR="/data/adb/service.d"
mkdir -p "$SERVICE_DIR"
cp -f "$MODPATH/service.sh" "$SERVICE_DIR/glibc_runner_service.sh"
chmod 755 "$SERVICE_DIR/glibc_runner_service.sh"

# ── Done ──
ui_print ""
ui_print "============================================="
ui_print "   Glibc Runner Installation Complete"
ui_print "============================================="
ui_print ""
ui_print "Next steps:"
ui_print "  1) Open module WebUI in KernelSU Manager"
ui_print "  2) Install Node.js runtime"
ui_print "  3) Install OpenClaw (optional)"
ui_print ""
ui_print "CLI:"
ui_print "  su -c 'glibc-runner.service start|stop|restart|status'"
ui_print ""
