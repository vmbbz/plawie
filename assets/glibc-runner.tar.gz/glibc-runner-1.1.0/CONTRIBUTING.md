# Contributing to Glibc Runner

Thanks for your interest in contributing! This project brings native Node.js and OpenClaw support to Android via a KernelSU/Magisk module.

## Getting Started

### Prerequisites

- A rooted Android device (ARM64) with KernelSU, Magisk, or APatch
- [Termux](https://f-droid.org/packages/com.termux/) for on-device development
- Basic knowledge of shell scripting and the Magisk module format

### Development Setup

```bash
# Clone the repo
git clone https://github.com/repotitan/glibc-runner-for-openclaw.git
cd glibc-runner-for-openclaw

# The glibc.tar.xz blob is NOT in git (too large)
# Download it from the latest release or build your own
```

### Project Structure

```
glibc-runner/
├── settings.ini              # Central config — sourced by ALL scripts
├── scripts/
│   ├── bootstrap.sh          # Node.js download + install state machine
│   ├── glibc-runner.service  # Service manager (start/stop/restart/status/log)
│   ├── update.sh             # Updater (node-apply, openclaw-apply, cleanup)
│   ├── start.sh              # Boot entry point
│   ├── glibc-runner.inotify  # inotifyd handler for enable/disable toggle
│   └── npm-fix-bins.sh       # Regenerates glibc wrapper scripts for bin/
└── config/
    └── bootstrap.default.env # Default bootstrap config
```

### Key Design Principles

1. **Single source of truth** — `settings.ini` defines all paths. Scripts source it, never hardcode paths.
2. **pgrep, not PID files** — Process detection uses `pgrep -f openclaw-gateway` because PID files are unreliable on Android (nohup wrapper PID dies immediately, the real server is a forked child).
3. **pgrep + kill, not pkill** — `pkill -f` hangs on some devices (exit code 144/SIGALRM). Always `pgrep -f` to get PIDs, then `kill` them in a loop.
4. **Single implementation** — All process management goes through `glibc-runner.service`. WebUI, action.sh, start.sh, and inotify all call the same script.
5. **Wrapper pattern** — Every binary under `node/bin/` is a shell wrapper that invokes the glibc dynamic linker. `npm-fix-bins.sh` regenerates these after `npm install -g`.

### How the Glibc Wrapper Works

When `npm install -g` creates a new binary (e.g., `openclaw`), it's a Node.js script with a `#!/usr/bin/env node` shebang — which won't work on Android (no `/usr/bin/env`, and the node binary needs glibc). The `npm-fix-bins.sh` script wraps every such binary:

```bash
#!/system/bin/sh
GLIBC="/data/adb/glibc-runner/lib/glibc"
LD="$GLIBC/ld-linux-aarch64.so.1"
NODE="/data/adb/glibc-runner/node/bin/node.real"
SCRIPT="/data/adb/glibc-runner/node/bin/<original-script>"
exec "$LD" --library-path "$GLIBC" "$NODE" "$SCRIPT" "$@"
```

### Bootstrap State Machine

```
BOOTSTRAP_READY → NODE_INSTALLING → NODE_READY
                                  → NODE_INSTALL_FAILED
```

State is stored in `/data/adb/glibc-runner/run/bootstrap-state.env`.

---

## Making Changes

### Code Style

- **Shell scripts**: POSIX sh compatible (`#!/system/bin/sh`), no bashisms
- **Indentation**: 2 spaces
- **Variables**: snake_case, prefixed with `_` for locals
- **Functions**: `cmd_<name>` for command handlers
- **Logging**: Use `log Info/Warning/Error "message"` (defined in settings.ini)
- **Process detection**: Always `pgrep -f`, never `pkill -f` or PID files
- **JavaScript**: `'use strict'`, const/let (no var), 2-space indent

### Testing Locally

```bash
# Deploy changes to live module (as root)
su -c 'cp scripts/glibc-runner.service /data/adb/glibc-runner/scripts/'
su -c 'cp webroot/* /data/adb/modules/glibc-runner/webroot/'

# Test service commands
su -c 'glibc-runner.service status'
su -c 'glibc-runner.service start'
su -c 'glibc-runner.service stop'

# Check logs
su -c 'glibc-runner.service log openclaw'
su -c 'glibc-runner.service log service'
```

### Building the Flashable Zip

```bash
zip -r glibc-runner-v1.1.0.zip . \
  -x '.git/*' 'glibc-runner/node/*' 'glibc-runner/lib/glibc/*' \
  'README.md' 'CONTRIBUTING.md' 'LICENSE' '.gitignore'
```

Note: `glibc.tar.xz` must be in the root for the zip to work.

---

## Building the Glibc Blob

The `glibc.tar.xz` contains 21 prebuilt aarch64 libraries. To build your own:

1. Use an aarch64 Linux environment (or cross-compile)
2. Build glibc 2.39+ with `--host=aarch64-linux-gnu`
3. Build OpenSSL 3.x, libstdc++ 14.x, zlib
4. Collect the shared libraries:

```
ld-linux-aarch64.so.1  libc.so.6      libcrypt.so.2
libcrypt.so.2.0.0      libcrypto.so.3 libdl.so.2
libgcc_s.so.1          libm.so.6      libnss_dns.so.2
libnss_files.so.2      libpthread.so.0 libresolv.so
libresolv.so.2         librt.so.1     libssl.so.3
libstdc++.so.6         libstdc++.so.6.0.34
libz.so.1              ld.so          libc.so
```

5. `tar -cJf glibc.tar.xz -C /path/to/libs .`

---

## Pull Requests

1. Fork the repo
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Make your changes
4. Test on a real device
5. Submit a PR with:
   - Clear description of what changed and why
   - Test results (device model, KSU/Magisk version)

---

## Reporting Issues

Please include:
- Device model and Android version
- Root solution and version (KSU/Magisk/APatch)
- Output of `su -c 'glibc-runner.service status'`
- Relevant logs: `su -c 'glibc-runner.service log openclaw'`

---

## License

By contributing, you agree that your contributions will be licensed under the [MIT License](LICENSE).
