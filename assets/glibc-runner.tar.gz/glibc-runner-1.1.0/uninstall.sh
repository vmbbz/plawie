#!/system/bin/sh
# ====================================================
#  Glibc Runner Module - Uninstall Script
# ====================================================

# Ensure busybox is available (KSU/APatch/Magisk)
if ! command -v busybox >/dev/null 2>&1; then
  export PATH="/data/adb/ksu/bin:/data/adb/ap/bin:/data/adb/magisk:$PATH"
fi

# Stop gateway and service before removal
if [ -f "/data/adb/glibc-runner/scripts/glibc-runner.service" ]; then
  /data/adb/glibc-runner/scripts/glibc-runner.service stop >/dev/null 2>&1 || true
  sleep 1
fi

# Kill openclaw gateway processes (pgrep + kill, not pkill)
for _pid in $(pgrep -f "openclaw-gateway" 2>/dev/null) $(pgrep -f "openclaw gateway" 2>/dev/null); do
  kill "$_pid" 2>/dev/null || true
done
sleep 1
for _pid in $(pgrep -f "openclaw-gateway" 2>/dev/null); do
  kill -9 "$_pid" 2>/dev/null || true
done

# Kill any lingering node processes from glibc-runner
for _pid in $(pgrep -f "/data/adb/glibc-runner" 2>/dev/null); do
  kill "$_pid" 2>/dev/null || true
done
unset _pid

# Kill inotifyd watcher
for _pid in $(busybox pidof inotifyd 2>/dev/null); do
  if grep -q "glibc-runner.inotify" "/proc/$_pid/cmdline" 2>/dev/null; then
    kill -9 "$_pid" 2>/dev/null || true
  fi
done

# Remove boot service script
rm -f "/data/adb/service.d/glibc_runner_service.sh"

# Remove glibc-runner data directory
rm -rf /data/adb/glibc-runner
