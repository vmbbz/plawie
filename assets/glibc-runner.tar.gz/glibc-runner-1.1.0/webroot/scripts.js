/* ====================================================
 *  Glibc Runner — WebUI Scripts
 *  KernelSU WebUI management interface
 *  Tabs: Node.js + Openclaw
 * ==================================================== */

'use strict';

// ── Constants ───────────────────────────────────────
const BOOTSTRAP = '/data/adb/glibc-runner/scripts/bootstrap.sh';
const FIX_BINS  = '/data/adb/glibc-runner/scripts/npm-fix-bins.sh';
const LOG_FILE  = '/data/adb/glibc-runner/run/bootstrap.log';
const MOD_PROP  = '/data/adb/modules/glibc-runner/module.prop';

// Openclaw paths — installed inside glibc-runner via npm install -g
const OC_BASE      = '/data/adb/glibc-runner';
const OC_NODE      = OC_BASE + '/node/bin/node';
const OC_NPM       = OC_BASE + '/node/bin/npm';
const OC_BIN       = OC_BASE + '/node/bin/openclaw';
const OC_PKG_DIR   = OC_BASE + '/node/lib/node_modules/openclaw';
const OC_HOME      = OC_BASE + '/home';
const OC_LOG       = OC_BASE + '/run/openclaw.log';
const OC_SETTINGS  = OC_BASE + '/settings.ini';
const SERVICE      = OC_BASE + '/scripts/glibc-runner.service';
const UPDATE       = OC_BASE + '/scripts/update.sh';

// ── State ───────────────────────────────────────────
const S = {
  follow: true, poll: null, busy: false,
  ocFollow: true, ocBusy: false, ocGwRunning: false,
  lastNodeState: '', lastNodeAction: ''
};
let toastTimer = null;

// ── Helpers ─────────────────────────────────────────
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);
const now = () => new Date().toLocaleTimeString();

// ── Theme ───────────────────────────────────────────
function initTheme() {
  const saved = localStorage.getItem('gr-theme');
  if (saved === 'dark') document.body.classList.add('dark-theme');
  updateThemeIcon();
}

function toggleTheme() {
  document.body.classList.toggle('dark-theme');
  localStorage.setItem('gr-theme',
    document.body.classList.contains('dark-theme') ? 'dark' : 'light');
  updateThemeIcon();
}

function updateThemeIcon() {
  const btn = $('#theme-toggle');
  if (btn) btn.textContent = document.body.classList.contains('dark-theme')
    ? '\u{1F319}' : '\u{2600}\u{FE0F}';
}

// ── Shell Exec ──────────────────────────────────────
function execShell(cmd) {
  return new Promise((resolve, reject) => {
    if (!window.ksu || typeof window.ksu.exec !== 'function') {
      reject(new Error('ksu.exec not available'));
      return;
    }
    const cb = '__gr_' + Date.now() + '_' + Math.floor(Math.random() * 9999);
    window[cb] = (errno, stdout, stderr) => {
      delete window[cb];
      resolve({ errno: Number(errno) || 0, stdout: stdout || '', stderr: stderr || '' });
    };
    try {
      window.ksu.exec(cmd, '{}', cb);
    } catch (e) {
      delete window[cb];
      reject(e);
    }
  });
}

// ── KV Parser ───────────────────────────────────────
function parseKV(out) {
  const map = {};
  (out || '').split(/\r?\n/).forEach(line => {
    const i = line.indexOf('=');
    if (i > 0) map[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  });
  return map;
}

// ── Toast ───────────────────────────────────────────
function showToast(msg, type = 'ok', hold = 2400) {
  const el = $('#toast');
  if (!el) return;
  el.textContent = msg;
  el.className = 'toast ' + type;
  requestAnimationFrame(() => el.classList.add('show'));
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), hold);
}

// ── Confirm Dialog ──────────────────────────────────
function showConfirm(title, message) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.innerHTML = `
      <div class="dialog">
        <h3>${title}</h3>
        <p>${message}</p>
        <div class="dialog-btns">
          <button class="btn cancel-btn">Cancel</button>
          <button class="btn pri confirm-btn">Confirm</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('show'));
    const close = (result) => {
      overlay.classList.remove('show');
      setTimeout(() => overlay.remove(), 250);
      resolve(result);
    };
    overlay.querySelector('.cancel-btn').onclick = () => close(false);
    overlay.querySelector('.confirm-btn').onclick = () => close(true);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(false); });
  });
}

// ── Tabs ────────────────────────────────────────────
function initTabs() {
  $$('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      $$('.tab').forEach(t => t.classList.remove('active'));
      $$('.tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      const target = $('#tab-' + tab.dataset.tab);
      if (target) target.classList.add('active');
    });
  });
}

// ══════════════════════════════════════════════════════
//  NODE.JS TAB
// ══════════════════════════════════════════════════════

function setText(sel, v) {
  const el = $(sel);
  if (el) el.textContent = v;
}

function setStateDot(kind, text, pulse) {
  const el = $('#state');
  if (!el) return;
  el.innerHTML = `<span class="dot ${kind}${pulse ? ' pulse' : ''}"></span>${text}`;
}

async function refreshStatus() {
  try {
    const r = await execShell(`${BOOTSTRAP} status`);
    const kv = parseKV((r.stdout || '') + (r.stderr || ''));
    const st = kv.state || 'UNKNOWN';

    if (/FAILED/.test(st)) setStateDot('err', st, false);
    else if (/^NODE_READY$/.test(st)) setStateDot('ok', st, false);
    else if (/INSTALLING/.test(st)) setStateDot('warn', st, true);
    else setStateDot('warn', st, false);

    setText('#node-ready', kv.node_ready === '1' ? 'Ready' : 'Not ready');
    setText('#node-ver', kv.node_version || '\u2014');
    setText('#npm-ver', kv.npm_version || '\u2014');

    const action = kv.last_action || '\u2014';
    const ts = kv.last_ts;
    let lastStr = action;
    if (ts && ts !== '0' && ts !== '\u2014') {
      const d = new Date(Number(ts) * 1000);
      if (!isNaN(d.getTime())) lastStr += ' \u00B7 ' + d.toLocaleTimeString();
    }
    setText('#last', lastStr);

    const installBtn = $('#install-node');
    if (installBtn) installBtn.disabled = S.busy || /INSTALLING/.test(st);

    // Detect background install completion: state transitions
    const curAction = kv.last_action || '';
    if (S.lastNodeAction && S.lastNodeAction !== curAction) {
      if (/success/.test(curAction)) {
        showToast(`Node.js ${kv.node_version || ''} installed successfully`, 'ok', 4000);
      } else if (/fail/.test(curAction)) {
        showToast('Node.js install failed — check log', 'err', 5000);
      }
    }
    // Detect state transition from INSTALLING → NODE_READY or FAILED
    if (S.lastNodeState && S.lastNodeState !== st) {
      if (/INSTALLING/.test(S.lastNodeState) && /^NODE_READY$/.test(st)) {
        showToast(`Node.js ready · ${kv.node_version || ''}`, 'ok', 4000);
      } else if (/INSTALLING/.test(S.lastNodeState) && /FAILED/.test(st)) {
        showToast('Node.js install failed', 'err', 5000);
      }
    }
    S.lastNodeState = st;
    S.lastNodeAction = curAction;
  } catch (e) {
    setStateDot('warn', 'Unknown', false);
  }
}

async function refreshLog() {
  try {
    const r = await execShell(`tail -n 250 ${LOG_FILE} 2>/dev/null`);
    const el = $('#log');
    if (!el) return;
    el.textContent = (r.stdout || '').trim() || 'Ready.';
    if (S.follow) el.scrollTop = el.scrollHeight;
  } catch (e) { /* silent */ }
}

async function runAction(cmd, okMsg) {
  if (S.busy) return;
  S.busy = true;
  const installBtn = $('#install-node');
  const fixBinsBtn = $('#fix-bins');
  if (installBtn) { installBtn.disabled = true; installBtn.classList.add('loading'); }
  if (fixBinsBtn) { fixBinsBtn.disabled = true; fixBinsBtn.classList.add('loading'); }

  try {
    // Fire-and-forget: launch in background so ksu.exec returns immediately
    // This prevents blocking the callback thread which freezes all polling/UI
    await execShell(`nohup ${cmd} > ${LOG_FILE} 2>&1 &`);
    showToast(okMsg, 'ok');
  } catch (e) {
    showToast(String(e), 'err', 3500);
  } finally {
    S.busy = false;
    if (installBtn) installBtn.classList.remove('loading');
    if (fixBinsBtn) fixBinsBtn.classList.remove('loading');
    // Polling cycle (2.5s) will pick up log + status changes automatically
  }
}

async function loadModuleVersion() {
  try {
    const r = await execShell(`grep '^version=' ${MOD_PROP} | cut -d'=' -f2`);
    const ver = (r.stdout || '').trim();
    if (ver) setText('#version-text', 'v' + ver);
  } catch (e) { /* silent */ }
}

// ══════════════════════════════════════════════════════
//  OPENCLAW TAB
// ══════════════════════════════════════════════════════

function setOcDot(sel, kind, text, pulse) {
  const el = $(sel);
  if (!el) return;
  el.innerHTML = `<span class="dot ${kind}${pulse ? ' pulse' : ''}"></span>${text}`;
}

async function refreshOcStatus() {
  try {
    // Check if openclaw is installed inside glibc-runner's node
    const installed = await execShell(`[ -f "${OC_BIN}" ] && echo yes || echo no`);
    const isInstalled = (installed.stdout || '').trim() === 'yes';
    setText('#oc-installed', isInstalled ? 'Yes' : 'Not installed');

    if (!isInstalled) {
      setOcDot('#oc-gw-state', 'warn', 'Not installed', false);
      setText('#oc-version', '\u2014');
      setText('#oc-gw-port', '\u2014');
      updateGwToggle(false);
      return;
    }

    // Get version via glibc-runner's node
    const verR = await execShell(`. ${OC_SETTINGS} && openclaw --version 2>/dev/null | head -1`);
    const verLine = (verR.stdout || '').trim();
    setText('#oc-version', verLine || 'unknown');

    // Detect real gateway process: openclaw forks "openclaw-gateway" which binds the port.
    // PID files are unreliable (nohup wrapper PID dies immediately), so use pgrep.
    const gwR = await execShell(`
      _pid=$(pgrep -f "openclaw-gateway" 2>/dev/null | head -1)
      if [ -n "$_pid" ] && [ -d "/proc/$_pid" ]; then
        echo "running"
        _port=$(cat /proc/$_pid/cmdline 2>/dev/null | tr '\\0' ' ' | grep -oE '\\-\\-port [0-9]+' | awk '{print $2}')
        echo "port=\${_port:-18789}"
        echo "pid=$_pid"
      else
        echo "stopped"
        echo "port=18789"
      fi
    `);
    const gwOut = (gwR.stdout || '').trim();
    const gwRunning = gwOut.startsWith('running');
    S.ocGwRunning = gwRunning;

    const portMatch = gwOut.match(/port=(\d+)/);
    setText('#oc-gw-port', portMatch ? portMatch[1] : '18789');

    setOcDot('#oc-gw-state', gwRunning ? 'ok' : 'warn', gwRunning ? 'Running' : 'Stopped', false);
    updateGwToggle(gwRunning);
  } catch (e) {
    setOcDot('#oc-gw-state', 'err', 'Error', false);
    updateGwToggle(false);
  }
}

function updateGwToggle(running) {
  const btn = $('#oc-gw-toggle');
  if (!btn) return;
  btn.classList.remove('on', 'off');
  btn.classList.add(running ? 'on' : 'off');
}

async function toggleGateway() {
  const btn = $('#oc-gw-toggle');
  if (!btn || S.ocBusy) return;
  S.ocBusy = true;
  btn.classList.add('loading');

  try {
    if (S.ocGwRunning) {
      const r = await execShell(`${SERVICE} stop 2>&1`);
      showToast(r.errno === 0 ? 'Gateway stopped' : 'Stop failed', r.errno === 0 ? 'ok' : 'err');
    } else {
      const r = await execShell(`${SERVICE} start 2>&1`);
      const out = (r.stdout || '').trim();
      const ok = r.errno === 0 && !out.includes('failed');
      showToast(ok ? 'Gateway started' : 'Gateway start failed', ok ? 'ok' : 'err', ok ? 2400 : 3500);
    }
  } catch (e) {
    showToast(String(e), 'err', 3500);
  } finally {
    S.ocBusy = false;
    btn.classList.remove('loading');
    setTimeout(refreshOcStatus, 1500);
  }
}

async function installOpenclaw() {
  if (S.ocBusy) return;

  const verInput = $('#oc-ver-input');
  const rawVer = (verInput ? verInput.value : '').trim();
  if (!rawVer) {
    showToast('Enter version or "latest"', 'err', 2500);
    return;
  }

  // Validate: "latest" or version like 2026.4.9 / 2026.4.9-beta.1
  if (rawVer !== 'latest' && !/^\d{4}\.\d+\.\d+(-[\w.]+)?$/.test(rawVer)) {
    showToast('Invalid version format', 'err', 2500);
    return;
  }

  const displayVer = rawVer === 'latest' ? 'latest version' : rawVer;
  const ok = await showConfirm('Install Openclaw', `Install openclaw@${displayVer}?`);
  if (!ok) return;

  S.ocBusy = true;
  const installBtn = $('#oc-install');
  if (installBtn) { installBtn.disabled = true; installBtn.classList.add('loading'); }

  try {
    // Fire-and-forget: use openclaw-apply-bg to run in background
    // This returns immediately so ksu.exec doesn't block the UI
    const cmd = `${UPDATE} openclaw-apply-bg '${rawVer}' 2>&1`;
    const r = await execShell(cmd);
    showToast(`Installing openclaw@${displayVer}... check log for progress`, 'ok', 3000);
  } catch (e) {
    showToast(String(e), 'err', 3500);
  } finally {
    S.ocBusy = false;
    if (installBtn) { installBtn.disabled = false; installBtn.classList.remove('loading'); }
    // Polling cycle (2.5s) will pick up status + log changes automatically
    await refreshOcStatus();
  }
}

async function refreshOcLog() {
  try {
    // Show both gateway log AND latest install-bg log (if any active install)
    const r = await execShell(`
      _bg_log=$(ls -t ${OC_BASE}/run/update-state/openclaw-apply-bg-*.log 2>/dev/null | head -1)
      if [ -n "$_bg_log" ]; then
        echo "=== Install Log ==="
        tail -n 150 "$_bg_log" 2>/dev/null
        echo ""
        echo "=== Gateway Log ==="
      fi
      tail -n 100 ${OC_LOG} 2>/dev/null
    `);
    const el = $('#oc-log');
    if (!el) return;
    el.textContent = (r.stdout || '').trim() || 'Ready.';
    if (S.ocFollow) el.scrollTop = el.scrollHeight;
  } catch (e) { /* silent */ }
}

// ── Follow/Clear for Openclaw ───────────────────────
function updateOcFollowBtn() {
  const btn = $('#oc-follow');
  if (!btn) return;
  btn.textContent = S.ocFollow ? 'Follow' : 'Paused';
  btn.className = 'log-action-btn ' + (S.ocFollow ? 'follow-active' : 'follow-paused');
}

// ── Signal File Notifications ──────────────────────
// Background jobs write signal files to /run/ when done
// Format: "ok|message" or "err|message"
const NOTIFY_DIR = OC_BASE + '/run';

async function checkNotifySignals() {
  try {
    const r = await execShell(`
      for f in ${NOTIFY_DIR}/notify-*.signal; do
        [ -f "$f" ] || continue
        echo "FILE=$(basename "$f")"
        cat "$f"
        rm -f "$f"
      done
    `);
    const out = (r.stdout || '').trim();
    if (!out) return;

    // Parse each signal: "FILE=notify-openclaw.signal\nok|Openclaw installed"
    out.split('FILE=').forEach(block => {
      block = block.trim();
      if (!block) return;
      const lines = block.split('\n');
      const payload = lines.slice(1).join('\n').trim();
      if (!payload) return;
      const sep = payload.indexOf('|');
      if (sep < 0) return;
      const type = payload.slice(0, sep);
      const msg = payload.slice(sep + 1);
      showToast(msg, type === 'ok' ? 'ok' : 'err', type === 'ok' ? 4000 : 5000);
    });
  } catch (e) { /* silent */ }
}

// ── Maintenance ────────────────────────────────────
let _maintCache = {};

async function refreshMaintInfo() {
  try {
    const r = await execShell(`${UPDATE} backup-info 2>/dev/null`);
    const kv = parseKV((r.stdout || '') + (r.stderr || ''));
    _maintCache = kv;

    const hasBackup = kv.has_node_backup === '1';
    const backupEl = $('#maint-backup');
    if (backupEl) {
      backupEl.textContent = hasBackup
        ? `${kv.node_backup_ver || '?'} (${kv.node_backup_size || '?'})`
        : 'None';
    }

    const tempEl = $('#maint-temp');
    if (tempEl) {
      const logs = parseInt(kv.bg_logs_count || '0', 10);
      const total = kv.total_size || '0K';
      tempEl.textContent = logs > 0 || total !== '0K'
        ? `${logs} log${logs !== 1 ? 's' : ''} · ${total}`
        : 'Clean';
    }

    const restoreBtn = $('#node-restore');
    if (restoreBtn) restoreBtn.disabled = !hasBackup || S.busy;

    const cleanBtn = $('#cleanup');
    if (cleanBtn) {
      const total = kv.total_size || '0K';
      cleanBtn.disabled = (total === '0K' || total === '0') && !hasBackup;
    }
  } catch (e) { /* silent */ }
}

async function nodeRestore() {
  if (S.busy) return;
  const ok = await showConfirm('Restore Node.js',
    `Rollback to ${_maintCache.node_backup_ver || 'previous version'}?<br>Current Node.js will be replaced by the backup.`);
  if (!ok) return;

  S.busy = true;
  const btn = $('#node-restore');
  if (btn) { btn.disabled = true; btn.classList.add('loading'); }

  try {
    const r = await execShell(`${UPDATE} node-rollback-last 2>&1`);
    const out = (r.stdout || '') + (r.stderr || '');
    const logEl = $('#log');
    if (logEl) { logEl.textContent = out || logEl.textContent; if (S.follow) logEl.scrollTop = logEl.scrollHeight; }
    showToast(r.errno === 0 ? 'Restore complete' : 'Restore failed', r.errno === 0 ? 'ok' : 'err', 3500);
  } catch (e) {
    showToast(String(e), 'err', 3500);
  } finally {
    S.busy = false;
    if (btn) btn.classList.remove('loading');
    await Promise.all([refreshStatus(), refreshMaintInfo()]);
  }
}

async function cleanupAll() {
  if (S.busy) return;
  const total = _maintCache.total_size || '0K';
  const ok = await showConfirm('Clean All',
    `Delete all backups, staging files, and logs?<br>This frees ~${total}. You will not be able to restore after this.`);
  if (!ok) return;

  S.busy = true;
  const btn = $('#cleanup');
  if (btn) { btn.disabled = true; btn.classList.add('loading'); }

  try {
    const r = await execShell(`${UPDATE} cleanup 2>&1`);
    const kv = parseKV((r.stdout || '') + (r.stderr || ''));
    showToast(`Cleaned · freed ${kv.cleanup_freed || total}`, 'ok', 3500);
  } catch (e) {
    showToast(String(e), 'err', 3500);
  } finally {
    S.busy = false;
    if (btn) btn.classList.remove('loading');
    await refreshMaintInfo();
  }
}

// ── Openclaw Maintenance ───────────────────────────
let _ocMaintCache = {};

async function refreshOcMaintInfo() {
  try {
    const r = await execShell(`${UPDATE} openclaw-info 2>/dev/null`);
    const kv = parseKV((r.stdout || '') + (r.stderr || ''));
    _ocMaintCache = kv;

    const cacheEl = $('#oc-maint-cache');
    if (cacheEl) {
      const sz = kv.npm_cache_size || '0K';
      cacheEl.textContent = sz === '0K' || sz === '0' ? 'Clean' : sz;
    }

    const pkgEl = $('#oc-maint-pkg');
    if (pkgEl) {
      const sz = kv.oc_pkg_size || '0K';
      pkgEl.textContent = sz === '0K' || sz === '0' ? 'Not installed' : sz;
    }

    const logsEl = $('#oc-maint-logs');
    if (logsEl) {
      const gwSz = kv.gw_log_size || '0K';
      const cnt = parseInt(kv.oc_logs_count || '0', 10);
      const parts = [];
      if (gwSz !== '0K' && gwSz !== '0') parts.push('gw: ' + gwSz);
      if (cnt > 0) parts.push(cnt + ' bg-log' + (cnt !== 1 ? 's' : ''));
      logsEl.textContent = parts.length > 0 ? parts.join(' · ') : 'Clean';
    }

    // Enable rollback button only if openclaw is installed (user enters version to rollback to)
    const rollBtn = $('#oc-rollback');
    if (rollBtn) {
      const hasOc = kv.oc_version && kv.oc_version !== '';
      rollBtn.disabled = !hasOc || S.ocBusy;
    }

    // Enable cleanup button if cache or logs exist
    const cleanBtn = $('#oc-cleanup');
    if (cleanBtn) {
      const cache = kv.npm_cache_size || '0K';
      const cnt = parseInt(kv.oc_logs_count || '0', 10);
      const gwSz = kv.gw_log_size || '0K';
      cleanBtn.disabled = (cache === '0K' || cache === '0') && cnt === 0 && (gwSz === '0K' || gwSz === '0');
    }
  } catch (e) { /* silent */ }
}

async function ocRollback() {
  if (S.ocBusy) return;

  const verInput = $('#oc-ver-input');
  const rawVer = (verInput ? verInput.value : '').trim();
  if (!rawVer || rawVer === 'latest') {
    showToast('Enter the version to rollback to (e.g. 2026.4.1)', 'err', 3500);
    return;
  }
  if (!/^\d{4}\.\d+\.\d+(-[\w.]+)?$/.test(rawVer)) {
    showToast('Invalid version format', 'err', 2500);
    return;
  }

  const ok = await showConfirm('Rollback Openclaw',
    `Reinstall openclaw@${rawVer}?<br>This will stop the gateway, install the specified version, then restart.`);
  if (!ok) return;

  S.ocBusy = true;
  const btn = $('#oc-rollback');
  if (btn) { btn.disabled = true; btn.classList.add('loading'); }

  try {
    const r = await execShell(`${UPDATE} openclaw-apply '${rawVer}' 2>&1`);
    const out = (r.stdout || '') + (r.stderr || '');
    const logEl = $('#oc-log');
    if (logEl) { logEl.textContent = out || logEl.textContent; if (S.ocFollow) logEl.scrollTop = logEl.scrollHeight; }
    showToast(r.errno === 0 ? `Rolled back to ${rawVer}` : 'Rollback failed', r.errno === 0 ? 'ok' : 'err', 3500);
  } catch (e) {
    showToast(String(e), 'err', 3500);
  } finally {
    S.ocBusy = false;
    if (btn) btn.classList.remove('loading');
    await Promise.all([refreshOcStatus(), refreshOcMaintInfo()]);
  }
}

async function ocCleanup() {
  if (S.ocBusy) return;
  const cache = _ocMaintCache.npm_cache_size || '0K';
  const ok = await showConfirm('Clean Openclaw Cache',
    `Delete npm cache (~${cache}), gateway logs, and bg-logs?<br>Openclaw itself is not affected.`);
  if (!ok) return;

  S.ocBusy = true;
  const btn = $('#oc-cleanup');
  if (btn) { btn.disabled = true; btn.classList.add('loading'); }

  try {
    const r = await execShell(`${UPDATE} npm-cache-clean 2>&1`);
    const kv = parseKV((r.stdout || '') + (r.stderr || ''));
    showToast(`Cleaned · freed ${kv.cleanup_freed || cache}`, 'ok', 3500);
  } catch (e) {
    showToast(String(e), 'err', 3500);
  } finally {
    S.ocBusy = false;
    if (btn) btn.classList.remove('loading');
    await refreshOcMaintInfo();
  }
}

// ══════════════════════════════════════════════════════
//  INIT
// ══════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initTabs();

  // Theme toggle
  const themeBtn = $('#theme-toggle');
  if (themeBtn) themeBtn.addEventListener('click', toggleTheme);

  // ── Node.js tab ──
  const followBtn = $('#follow');
  if (followBtn) {
    followBtn.textContent = S.follow ? 'Follow' : 'Paused';
    followBtn.className = 'log-action-btn ' + (S.follow ? 'follow-active' : 'follow-paused');
    followBtn.addEventListener('click', () => {
      S.follow = !S.follow;
      followBtn.textContent = S.follow ? 'Follow' : 'Paused';
      followBtn.className = 'log-action-btn ' + (S.follow ? 'follow-active' : 'follow-paused');
    });
  }

  const clearBtn = $('#clear');
  if (clearBtn) {
    clearBtn.className = 'log-action-btn clear-btn';
    clearBtn.addEventListener('click', async () => {
      const l = $('#log');
      if (l) l.textContent = '';
      await execShell(`: > ${LOG_FILE}`);
    });
  }

  const installBtn = $('#install-node');
  if (installBtn) {
    installBtn.addEventListener('click', async () => {
      const ver = ($('#node-ver-input') ? $('#node-ver-input').value : '').trim();
      if (!ver) { showToast('Enter Node.js version first', 'err', 2500); return; }
      if (!/^v?\d+\.\d+\.\d+$/.test(ver)) { showToast('Invalid format. Use vX.Y.Z', 'err', 2500); return; }
      const ok = await showConfirm('Install Node.js', `Install Node.js ${ver}?`);
      if (!ok) return;
      await runAction(`${BOOTSTRAP} install-node '${ver}'`, `Node install started \u00B7 ${now()}`);
    });
  }

  const fixBinsBtn = $('#fix-bins');
  if (fixBinsBtn) {
    fixBinsBtn.addEventListener('click', () => runAction(FIX_BINS, `Fix bins complete \u00B7 ${now()}`));
  }

  const refreshBtn = $('#refresh');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', async () => {
      await refreshStatus();
      await refreshLog();
      showToast('Refreshed', 'ok', 1200);
    });
  }

  // ── Maintenance ──
  const restoreBtn = $('#node-restore');
  if (restoreBtn) restoreBtn.addEventListener('click', nodeRestore);
  const cleanBtn = $('#cleanup');
  if (cleanBtn) cleanBtn.addEventListener('click', cleanupAll);

  // ── Openclaw tab ──
  const ocFollowBtn = $('#oc-follow');
  if (ocFollowBtn) {
    updateOcFollowBtn();
    ocFollowBtn.addEventListener('click', () => {
      S.ocFollow = !S.ocFollow;
      updateOcFollowBtn();
    });
  }

  const ocClearBtn = $('#oc-clear');
  if (ocClearBtn) {
    ocClearBtn.className = 'log-action-btn clear-btn';
    ocClearBtn.addEventListener('click', async () => {
      const l = $('#oc-log');
      if (l) l.textContent = '';
      await execShell(`: > ${OC_LOG}`);
    });
  }

  const ocGwToggle = $('#oc-gw-toggle');
  if (ocGwToggle) ocGwToggle.addEventListener('click', toggleGateway);

  const ocInstallBtn = $('#oc-install');
  if (ocInstallBtn) ocInstallBtn.addEventListener('click', installOpenclaw);

  const ocRefreshBtn = $('#oc-refresh');
  if (ocRefreshBtn) {
    ocRefreshBtn.addEventListener('click', async () => {
      await refreshOcStatus();
      await refreshOcLog();
      showToast('Refreshed', 'ok', 1200);
    });
  }

  // ── Openclaw Maintenance ──
  const ocRollbackBtn = $('#oc-rollback');
  if (ocRollbackBtn) ocRollbackBtn.addEventListener('click', ocRollback);
  const ocCleanBtn = $('#oc-cleanup');
  if (ocCleanBtn) ocCleanBtn.addEventListener('click', ocCleanup);

  // ── Initial load + polling ──
  (async () => {
    await loadModuleVersion();
    await Promise.all([refreshStatus(), refreshLog(), refreshOcStatus(), refreshOcLog(), refreshMaintInfo(), refreshOcMaintInfo()]);

    S.poll = setInterval(async () => {
      await Promise.all([refreshStatus(), refreshLog(), refreshOcStatus(), refreshOcLog(), checkNotifySignals(), refreshMaintInfo(), refreshOcMaintInfo()]);
    }, 2500);
  })();
});
