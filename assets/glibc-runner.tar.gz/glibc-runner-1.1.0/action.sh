#!/system/bin/sh
# ====================================================
#  Glibc Runner - KSU Manager Action Button Handler
#  Toggles openclaw gateway: running → stop, stopped → start
# ====================================================

SETTINGS="/data/adb/glibc-runner/settings.ini"
if [ -f "$SETTINGS" ]; then
  . "$SETTINGS"
else
  echo "Error: settings.ini not found"
  exit 1
fi

SERVICE_SCRIPT="${scripts_dir}/glibc-runner.service"
if [ ! -x "$SERVICE_SCRIPT" ]; then
  echo "Error: service script not found"
  exit 1
fi

# Check if openclaw is installed
if [ ! -x "$openclaw_bin" ]; then
  echo "============================================="
  echo "  Openclaw not installed"
  echo "============================================="
  echo "Open WebUI to install:"
  echo "  1) Install Node.js runtime"
  echo "  2) Install Openclaw"
  echo ""
  "$SERVICE_SCRIPT" status 2>/dev/null || true
  exit 0
fi

# Toggle gateway: detect BOTH child (openclaw-gateway) AND parent (openclaw gateway)
# When hung: parent "openclaw gateway" exists but child "openclaw-gateway" hasn't spawned
_gw_child=$(pgrep -f "openclaw-gateway" 2>/dev/null | head -1)
_gw_parent=$(pgrep -f "openclaw gateway" 2>/dev/null | head -1)

if [ -n "$_gw_child" ] || [ -n "$_gw_parent" ]; then
  echo "Stopping Openclaw gateway..."
  "$SERVICE_SCRIPT" stop
  # Also kill hung parent if child didn't exist
  if [ -z "$_gw_child" ] && [ -n "$_gw_parent" ]; then
    kill "$_gw_parent" 2>/dev/null
    sleep 1
    kill -9 "$_gw_parent" 2>/dev/null
    echo "Killed hung parent process (PID: $_gw_parent)"
  fi
else
  echo "Starting Openclaw gateway..."
  "$SERVICE_SCRIPT" start
fi
