#!/system/bin/sh
# ====================================================
#  Glibc Runner - Boot Service
#  Installed to /data/adb/service.d/glibc_runner_service.sh
#  Waits for boot_completed, then starts glibc-runner
# ====================================================

# Wait for boot to complete (max 120s)
_tries=0
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
  _tries=$((_tries + 1))
  [ $_tries -ge 60 ] && break
done
unset _tries

# Delay for network stabilization
sleep 25

# Check if module is disabled
MODULE_DIR="/data/adb/modules/glibc-runner"
[ -f "$MODULE_DIR/disable" ] && exit 0

# Start glibc-runner
START_SCRIPT="/data/adb/glibc-runner/scripts/start.sh"
if [ -x "$START_SCRIPT" ]; then
  "$START_SCRIPT"
fi
